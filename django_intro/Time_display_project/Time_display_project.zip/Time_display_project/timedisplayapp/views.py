from django.shortcuts import render, HttpResponse
from time import localtime, strftime


def index(request):
    return HttpResponse("Henry's website")


def hello(request):
    return HttpResponse("wasssssuuupppppppppp")


def hello_name(request, name):
    return HttpResponse(f"hello {name}")


def time(request):
    context = {
        "time": strftime("%Y-%m-%d %I:%M:%S %p", localtime())
    }
    return render(request, 'index.html', context)


def returnHTML(request):
    age = 21
    hobbies = ["getting twisted", "coding"]
    context = {
        "fn": "Henry",
        "age": age,
        "hobbies": hobbies
    }
    return render(request, "index.html", context)
