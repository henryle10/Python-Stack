from django.apps import AppConfig


class RandomWordGenAppConfig(AppConfig):
    name = 'Random_word_gen_app'
