from django.apps import AppConfig


class NinjaAppConfig(AppConfig):
    name = 'Ninja_app'
