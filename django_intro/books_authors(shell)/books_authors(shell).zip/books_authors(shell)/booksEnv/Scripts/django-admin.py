#!c:\users\henry\onedrive\documents\coding practice\python\django\django_intro\books_authors(shell)\booksenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
