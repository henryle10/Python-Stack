from django.apps import AppConfig


class SqlAppConfig(AppConfig):
    name = 'sql_app'
