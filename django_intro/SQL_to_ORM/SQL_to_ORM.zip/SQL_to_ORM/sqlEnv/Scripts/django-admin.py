#!c:\users\henry\onedrive\documents\coding practice\python\django\django_intro\sql_to_orm\sqlenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
